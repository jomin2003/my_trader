"""strategies/registry.py — Phase 4 (4.3): enable strategies via config."""
from __future__ import annotations
from typing import Dict,List
from .base import Strategy
_REGISTRY:Dict[str,Strategy]={}
def register(s): _REGISTRY[s.name]=s; return s
def get(name): return _REGISTRY[name]
def enabled_strategies(names): return [_REGISTRY[n] for n in names if n in _REGISTRY]
def all_names(): return sorted(_REGISTRY)
def clear(): _REGISTRY.clear()
