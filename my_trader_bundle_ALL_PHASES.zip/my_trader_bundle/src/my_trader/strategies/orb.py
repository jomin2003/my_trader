"""strategies/orb.py — reference strategy (Phase 4). Pure: no scanner import, no orders."""
from __future__ import annotations
from typing import List
from ..domain.models import MarketSnapshot,SignalCandidate
from .registry import register
class ORBStrategy:
    name="ORB"
    def __init__(self,or_bars=3): self.or_bars=or_bars
    def generate(self,snapshot:MarketSnapshot)->List[SignalCandidate]:
        c=snapshot.candles
        if len(c)<self.or_bars+1: return []
        oh=max(b.high for b in c[:self.or_bars]); ol=min(b.low for b in c[:self.or_bars])
        last=c[-1]; prev=c[-2]; atr=max(oh-ol,last.close*0.005); out=[]
        if last.close>oh and prev.close<=oh:
            out.append(SignalCandidate(snapshot.symbol,snapshot.security_id,"ORB",1,5.0,last.close,atr,last.ts,"ORB Long"))
        elif last.close<ol and prev.close>=ol:
            out.append(SignalCandidate(snapshot.symbol,snapshot.security_id,"ORB",-1,5.0,last.close,atr,last.ts,"ORB Short"))
        return out
register(ORBStrategy())
