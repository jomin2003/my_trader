"""strategies/base.py — Phase 4 (4.2): Strategy Protocol. No scanner import, no orders, no globals."""
from __future__ import annotations
from typing import Protocol,runtime_checkable,List
from ..domain.models import MarketSnapshot,SignalCandidate
@runtime_checkable
class Strategy(Protocol):
    name:str
    def generate(self,snapshot:MarketSnapshot)->List[SignalCandidate]: ...
