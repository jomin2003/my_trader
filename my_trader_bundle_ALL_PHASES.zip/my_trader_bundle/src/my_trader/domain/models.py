"""domain/models.py — Phase 4 (4.1): typed domain objects. Pure, no I/O."""
from __future__ import annotations
from dataclasses import dataclass,field
from typing import Optional
@dataclass(frozen=True)
class Candle:
    ts:str; open:float; high:float; low:float; close:float; volume:float
@dataclass(frozen=True)
class MarketSnapshot:
    symbol:str; security_id:str; candles:tuple; as_of:str
    @property
    def last(self): return self.candles[-1] if self.candles else None
@dataclass(frozen=True)
class SignalCandidate:
    symbol:str; security_id:str; strategy:str; direction:int; score:float; price:float; atr:float; time:str
    pattern:str=""; struct_sl:Optional[float]=None; struct_target:Optional[float]=None; meta:dict=field(default_factory=dict)
@dataclass(frozen=True)
class ExitPlan:
    decision_id:str; stop_price:float; target_price:float; initial_risk_per_unit:float
    expected_rr:float; chosen_source:str; rejected_sources:tuple=(); reason_codes:tuple=(); valid:bool=True
@dataclass(frozen=True)
class TradeDecision:
    decision_id:str; candidate:SignalCandidate; exit_plan:ExitPlan; qty:int; risk_weight:float
    config_version:str; model_version:Optional[str]=None; approved:bool=False
@dataclass(frozen=True)
class OrderIntent:
    decision_id:str; symbol:str; security_id:str; side:str; qty:int; order_type:str; price:float=0.0; trigger_price:Optional[float]=None
@dataclass
class Position:
    symbol:str; security_id:str; side:str; entry:float; sl:float; target:float; qty:int
    strategy:str; decision_id:str; opened_at:str; realized:float=0.0
@dataclass(frozen=True)
class Fill:
    symbol:str; side:str; qty:int; price:float; ts:str
@dataclass(frozen=True)
class ClosedTrade:
    symbol:str; strategy:str; side:str; entry:float; exit:float; qty:int; pnl:float; r:float; outcome:str; decision_id:str; config_version:str=""
