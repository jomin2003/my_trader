# CURRENT_BASELINE.md — baseline-v1 (Phase 0)

Freeze the working bot before refactoring:
```bash
git tag -a baseline-v1 -m "frozen baseline (paper)"
git push origin baseline-v1
```
Rollback anytime: `git checkout baseline-v1`.

## Frozen behaviour (do not change in Phase 0)
- Trading mode PAPER (`AUTO_TRADE_ENABLED=False`)
- Max risk/trade ₹500 · max open 5 · min score 6
- Cost model: slippage 3bps/way · taxes 6bps · brokerage 0
- Strategies: OB_SHORT · ORB · GAPFILL · CANDLE_STRUCT

## ML states at baseline (all neutral)
RR `RR_GATE_ENABLED=0` · Kronos soft · Vol gate off · Allocator shadow ·
Exit-policy v2 off · Audit on.

## Completion gate
app+scanner import · fixtures replay · CI green · paper default · no secrets exposed.
