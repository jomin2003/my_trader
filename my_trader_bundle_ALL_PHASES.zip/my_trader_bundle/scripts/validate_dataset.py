"""scripts/validate_dataset.py — Phase 7: dataset quality report."""
import argparse,glob,json,os,sys
import pandas as pd
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from data_validator import validate_ohlcv
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--csv-dir",required=True); ap.add_argument("--out",default="dataset_quality.json"); a=ap.parse_args()
    reports=[]
    for path in sorted(glob.glob(os.path.join(a.csv_dir,"*.csv"))):
        sym=os.path.splitext(os.path.basename(path))[0].upper()
        try: df=pd.read_csv(path)
        except Exception as e: reports.append({"symbol":sym,"ok":False,"issues":[f"read: {e}"]}); continue
        reports.append(validate_ohlcv(df,sym).as_dict())
    bad=[r for r in reports if not r["ok"]]
    json.dump({"symbols":len(reports),"failing":len(bad),"reports":reports},open(a.out,"w"),indent=2)
    print(f"validated {len(reports)} symbols · {len(bad)} with issues -> {a.out}")
if __name__=="__main__": main()
