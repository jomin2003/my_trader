"""scripts/diagnose_environment.py — Phase 0: sanitized env diagnostics."""
import importlib.util,os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config_report as cr
REQ=["flask","gunicorn","pandas","numpy","requests","dhanhq","pyotp"]; OPT=["lightgbm","yfinance"]
def have(m):
    try: return importlib.util.find_spec(m) is not None
    except Exception: return False
def main():
    ci="--ci" in sys.argv
    rep=cr.build_report(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    print(cr.format_report(rep)); print("\nDEPENDENCIES:")
    for m in REQ: print(f"  [req] {m:10} {'OK' if have(m) else 'MISSING'}")
    for m in OPT: print(f"  [opt] {m:10} {'OK' if have(m) else 'absent'}")
    cr.assert_no_secret_values(cr.format_report(rep))
    miss=[m for m in REQ if not have(m)]
    if miss: print(f"\n[X] missing required: {miss}",file=sys.stderr); sys.exit(1 if not ci else 0)
    print(f"\n[OK] mode={rep['trading_mode']} cfg={rep['config_version']}")
if __name__=="__main__": main()
