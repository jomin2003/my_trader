"""scripts/convert_csv_to_parquet.py — Phase 7: CSV -> partitioned Parquet."""
import argparse,glob,os,sys
import pandas as pd
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import parquet_store as ps
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--csv-dir",required=True); ap.add_argument("--out",default="./data"); ap.add_argument("--interval",default="5m"); a=ap.parse_args()
    n=0
    for path in sorted(glob.glob(os.path.join(a.csv_dir,"*.csv"))):
        sym=os.path.splitext(os.path.basename(path))[0].upper(); df=pd.read_csv(path)
        tc=next((c for c in df.columns if c.lower() in ("timestamp","ts","datetime","date","time")),None)
        if tc is None: print(f"skip {sym}: no timestamp"); continue
        df["_ts"]=pd.to_datetime(df[tc],errors="coerce",utc=True)
        for (y,m),g in df.groupby([df["_ts"].dt.year,df["_ts"].dt.month]):
            ps.write_partition(g.drop(columns=["_ts"]),a.out,a.interval,sym,int(y),int(m)); n+=1
    print(f"wrote {n} partitions (parquet_available={ps.available()})")
if __name__=="__main__": main()
