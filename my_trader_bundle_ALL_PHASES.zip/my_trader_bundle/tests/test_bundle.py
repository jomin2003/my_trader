"""Combined test suite for the whole bundle (Phases 0-10)."""
import os,sys
sys.path.insert(0,os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest

# ---- Phase 0 ----
def test_p0_config_report_secret_safe(monkeypatch):
    import config_report as cr
    monkeypatch.setenv("DHAN_ACCESS_TOKEN","tok_SECRET_abcdef123456")
    txt=cr.format_report()
    assert "tok_SECRET_abcdef123456" not in txt and "DHAN_ACCESS_TOKEN=SET" in txt
    cr.assert_no_secret_values(txt)
def test_p0_paper_default(monkeypatch):
    import config_report as cr
    monkeypatch.delenv("AUTO_TRADE_ENABLED",raising=False)
    assert cr.build_report()["trading_mode"]=="PAPER"

# ---- Phase 1 ----
def test_p1_rr_statuses_and_disabled(monkeypatch):
    import reason_codes as RC
    for s in ["DISABLED","MODEL_NOT_FOUND","META_NOT_FOUND","LIGHTGBM_NOT_AVAILABLE","SCHEMA_MISMATCH",
              "INSUFFICIENT_BARS","INVALID_FEATURE","PREDICTION_ERROR","LOW_CONFIDENCE","OUT_OF_RANGE","ACCEPTED","FALLBACK_USED"]:
        assert s in RC.RR_STATUSES
    monkeypatch.setenv("RR_GATE_ENABLED","0")
    for m in ("rr_predictor",): sys.modules.pop(m,None)
    import importlib,rr_predictor; importlib.reload(rr_predictor)
    pick,status,_=rr_predictor.best_rr_ex({"atr_frac":0.004},1)
    assert pick is None and status=="DISABLED"
def test_p1_decision_record_footer():
    import decision_audit as DA, reason_codes as RC
    DA.clear()
    dec=DA.DecisionRecord(decision_id=DA.make_decision_id("ORB","RELIANCE","BUY"),symbol="RELIANCE",
        strategy="ORB",side="BUY",signal_time="2026-08-04T10:15:00+05:30",final_exit_source="rr_model",
        rr_model_status="ACCEPTED",risk_weight=1.0,model_version="rr-v3",config_version="cfg-abc").add_reason(RC.Reason.RR_ACCEPTED)
    DA.record(dec); line=dec.telegram_line()
    for m in ["Decision","exit=rr_model","risk=1.00x","rr-v3","cfg=cfg-abc"]: assert m in line
    assert DA.last_for_symbol("reliance")["symbol"]=="RELIANCE"
def test_p1_coverage_mlstatus():
    import model_diagnostics as MD, reason_codes as RC
    MD.COVERAGE.reset(); MD.COVERAGE.on_signal(); MD.COVERAGE.on_attempt(); MD.COVERAGE.on_accept("RELIANCE")
    MD.COVERAGE.on_fallback("LOW_CONFIDENCE")
    assert MD.COVERAGE.snapshot()["accepted"]==1
    assert "Accepted: 1" in MD.mlstatus_text()
def test_p1_all_log_events():
    import decision_audit as DA, reason_codes as RC
    ev=[fn(x="t")["event"] for fn in (DA.signal_created,DA.signal_rejected,DA.model_prediction,DA.exit_resolved,
        DA.order_submitted,DA.order_rejected,DA.position_changed,DA.fallback_invoked,DA.state_restored)]
    assert set(ev)==set(RC.LOG_EVENTS)

# ---- Phase 2 ----
def test_p2_rule1_rr_supersedes():
    import exit_policy as EP, reason_codes as RC
    from exit_models import ExitConstraints
    C=ExitConstraints(0.003,0.05,1.2,500.0)
    base=EP.build_baseline_proposal(100,1,0.5,struct_sl=99.2,struct_tgt=101.6)
    rr=EP.build_rr_proposal(100,1,0.5,{"sl_mult":1.5,"tgt_mult":3.0},"rr-v3")
    p=EP.resolve("D",100,1,0.5,baseline=base,rr_proposal=rr,rr_status="ACCEPTED",kronos_target=101.0,constraints=C)
    assert p.chosen_source=="rr_model" and "structure" in p.rejected_sources
    assert list(p.reason_codes).count(RC.Reason.KRONOS_CONSTRAINT_APPLIED)==1
    assert RC.Reason.KRONOS_SKIPPED_RR_OWNS_EXIT in p.reason_codes
def test_p2_rule3_rejections():
    from exit_validation import validate_plan
    from exit_models import ExitConstraints
    import reason_codes as RC
    C=ExitConstraints(0.003,0.05,1.2,500.0)
    assert validate_plan(100,100.5,102,1,constraints=C)==(False,[RC.Reason.SL_WRONG_SIDE])
    assert validate_plan(100,99.0,101.0,1,constraints=C)==(False,[RC.Reason.RR_BELOW_MIN])
    assert validate_plan(100,99.0,102,1,qty=1000,constraints=C)==(False,[RC.Reason.MAX_RISK_EXCEEDED])
    ok,_=validate_plan(100,99.0,102,1,qty=10,constraints=C); assert ok

# ---- Phase 3 ----
def test_p3_settings_and_validator(monkeypatch):
    from config_loader import reload_settings
    import config_validator as V
    s=reload_settings("paper")
    assert s.application.mode=="paper" and s.execution.auto_trade_enabled is False
    assert s.version().startswith("cfg-"); V.validate(s)
    monkeypatch.setenv("APP_PROFILE","live"); monkeypatch.setenv("AUTO_TRADE_ENABLED","1"); monkeypatch.setenv("DHAN_CLIENT_ID","")
    s2=reload_settings("live")
    with pytest.raises(V.ConfigError): V.validate(s2)
    reload_settings("paper")

# ---- Phase 4 ----
def test_p4_registry_and_orb():
    from src.my_trader.domain.models import MarketSnapshot,Candle
    import src.my_trader.strategies.orb  # registers
    from src.my_trader.strategies import registry
    assert "ORB" in registry.all_names()
    bars=[Candle("t0",100,101,99.8,100.5,1000),Candle("t1",100.5,101,100.2,100.7,1000),
          Candle("t2",100.7,100.9,100.3,100.6,1000),Candle("t3",100.6,101.2,100.5,101.1,3000)]
    snap=MarketSnapshot("RELIANCE","1",tuple(bars),"t3")
    sigs=registry.get("ORB").generate(snap)
    assert sigs and sigs[0].direction==1
def test_p4_no_scanner_import():
    import inspect, src.my_trader.strategies.orb as orb
    assert "intraday_pattern_scanner" not in inspect.getsource(orb)

# ---- Phase 5 ----
def test_p5_cost_and_fill():
    from cost_model import CostModel
    from fill_model import resolve_same_bar
    c=CostModel(); assert abs(c.roundtrip_fraction()-0.0018)<1e-9; assert c.round_to_tick(100.04)==100.05
    assert resolve_same_bar(1,100,99,102,103,98).outcome=="SL"
    assert resolve_same_bar(1,100,99,102,103,98,policy="optimistic").outcome=="TGT"

# ---- Phase 6 ----
def test_p6_idempotent_and_reconcile(tmp_path):
    from sqlite_repository import SQLiteRepository
    from reconciler import reconcile
    import order_state_machine as sm
    repo=SQLiteRepository(str(tmp_path/"s.db")); did="ORB-RELIANCE-20260804T101500-BUY"
    assert repo.create_decision(did,"RELIANCE","ORB","BUY") is True
    assert repo.create_decision(did,"RELIANCE","ORB","BUY") is False
    repo.close()
    assert sm.can_transition("SIGNAL_CREATED","DECISION_APPROVED")
    with pytest.raises(sm.InvalidTransition): sm.transition("CLOSED","ENTRY_SUBMITTED")
    r=reconcile([{"symbol":"RELIANCE","qty":10}],[{"symbol":"TCS","qty":5}],[])
    assert r.halt_new_entries is True

# ---- Phase 7 ----
def test_p7_schema_and_validator():
    import feature_schema as fs
    import pandas as pd
    from data_validator import validate_ohlcv
    assert fs.schema_hash(["a","b"])==fs.schema_hash(["a","b"])!=fs.schema_hash(["a","c"])
    assert not fs.matches("fs-wrong")
    good=pd.DataFrame({"timestamp":["2026-08-04T09:15:00Z","2026-08-04T09:20:00Z"],"open":[100,101],
        "high":[102,102],"low":[99,100],"close":[101,101],"volume":[1000,900]})
    assert validate_ohlcv(good,"X").ok
    bad=good.copy(); bad.loc[0,"high"]=90
    assert not validate_ohlcv(bad,"X").ok

# ---- Phase 8 ----
def test_p8_manifest_and_promotion():
    from model_manifest import is_complete,REQUIRED_FIELDS
    import promotion_policy as pp
    from walk_forward import walk_forward_folds,has_no_leakage
    assert not is_complete({"model_version":"v"})[0]
    good={f:"x" for f in REQUIRED_FIELDS}
    good.update({"feature_schema_hash":"fs-abc","promotion_state":"candidate","validation_metrics":{
        "gini":0.3,"coverage":0.2,"expectancy_after_cost":0.1,"walk_forward_pass":True,
        "leakage_checks_pass":True,"baseline_comparison":{}}})
    assert pp.can_promote_to_paper(good,"fs-abc")[0]
    assert not pp.can_promote_to_live(good)[0]  # not paper-approved
    folds=walk_forward_folds(1000,4,12)
    assert folds and all(has_no_leakage(f,12) for f in folds)

# ---- Phase 9 ----
def test_p9_heat_correlation_allocator():
    from portfolio_risk import check_new_entry,RiskLimits
    from correlation_manager import CorrelationManager
    from portfolio_allocator import limited_update
    pos=[{"symbol":"A","entry":100,"sl":99,"qty":500,"strategy":"ORB","side":"BUY"}]
    allow,reasons=check_new_entry({"symbol":"B","entry":100,"sl":99,"qty":2000},pos,RiskLimits(max_portfolio_heat=2000))
    assert not allow
    cm=CorrelationManager({("A","B"):0.9,("A","C"):0.8},0.7,2)
    assert not cm.allow("A",["B","C"])[0]
    assert limited_update(1.0,1.5,0.15)==1.15

# ---- Phase 10 ----
def test_p10_metrics_and_redaction(monkeypatch):
    import metrics
    metrics.inc("symbols_processed",5); metrics.gauge("portfolio_heat",123)
    assert metrics.snapshot()["counters"]["symbols_processed"]==5
    from health_service import liveness
    assert liveness()["status"]=="alive"
    monkeypatch.setenv("TG_BOT_TOKEN","123456789:AABBCCDDEEFFgghhiijjkkllmmnnoopp")
    import importlib,logging_config,logging
    importlib.reload(logging_config)
    f=logging_config.RedactionFilter()
    rec=logging.LogRecord("x",20,"f",1,"token 123456789:AABBCCDDEEFFgghhiijjkkllmmnnoopp",None,None)
    f.filter(rec); assert "REDACTED" in rec.msg
